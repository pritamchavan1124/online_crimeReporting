package com.app.service;

import java.util.List;

import com.app.entities.SecurityQuestion;

public interface ISecurityQuestionService {

	//add a method to get all Addresses list
			List<SecurityQuestion> getAllSecQuestions();
}
