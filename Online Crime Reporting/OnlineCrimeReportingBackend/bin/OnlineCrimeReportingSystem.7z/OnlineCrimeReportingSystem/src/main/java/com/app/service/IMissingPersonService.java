package com.app.service;

import java.util.List;

import com.app.entities.MissingPerson;

public interface IMissingPersonService {

	List<MissingPerson> getAllMissingPeople();
}
