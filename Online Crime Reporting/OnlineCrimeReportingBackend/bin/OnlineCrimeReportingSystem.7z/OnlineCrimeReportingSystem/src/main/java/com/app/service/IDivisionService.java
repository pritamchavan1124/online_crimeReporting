package com.app.service;

import java.util.List;

import com.app.entities.Division;

public interface IDivisionService {
	//add a method to get all Addresses list
		List<Division> getAllDivisions();
}
