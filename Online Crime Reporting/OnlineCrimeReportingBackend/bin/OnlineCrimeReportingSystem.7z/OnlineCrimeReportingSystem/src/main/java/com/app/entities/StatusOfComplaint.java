package com.app.entities;

public enum StatusOfComplaint {
	PENDING,INPROCESS,RESOLVED;
}
