package com.app.service;

import java.util.List;

import com.app.entities.MissingMobile;

public interface IMissingMobileService {
	
	List<MissingMobile> getAllMissingMobile();

}
