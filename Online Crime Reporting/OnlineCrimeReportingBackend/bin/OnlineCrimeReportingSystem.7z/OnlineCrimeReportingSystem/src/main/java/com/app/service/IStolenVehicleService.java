package com.app.service;

import java.util.List;

import com.app.entities.StolenVehicle;

public interface IStolenVehicleService {
	
	List<StolenVehicle> getAllStolenVehicles();

}
