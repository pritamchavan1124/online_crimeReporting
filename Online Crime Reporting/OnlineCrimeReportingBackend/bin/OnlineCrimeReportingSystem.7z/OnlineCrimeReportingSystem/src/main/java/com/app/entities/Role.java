package com.app.entities;

public enum Role {
	ROLE_ADMIN, ROLE_COMPLAINANT, ROLE_POLICE_STATION;

}
