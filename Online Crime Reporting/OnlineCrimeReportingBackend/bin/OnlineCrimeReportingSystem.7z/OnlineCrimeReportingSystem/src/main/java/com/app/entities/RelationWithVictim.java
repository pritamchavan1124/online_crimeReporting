package com.app.entities;

public enum RelationWithVictim {
	SELF, PARENT, FRIEND, NEIGHBOUR, FAMILY_MEMBER, GUARDIAN, OTHER;
}
