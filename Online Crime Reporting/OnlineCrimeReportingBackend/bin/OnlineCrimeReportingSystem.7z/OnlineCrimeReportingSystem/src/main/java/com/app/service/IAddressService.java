package com.app.service;

import java.util.List;

import com.app.entities.Address;

public interface IAddressService {
//add a method to get all Addresses list
	List<Address> getAllAddresses();
}
